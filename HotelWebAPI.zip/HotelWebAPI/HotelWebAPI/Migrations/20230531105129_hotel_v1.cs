﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HotelWebAPI.Migrations
{
    /// <inheritdoc />
    public partial class hotel_v1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MenuTbl",
                columns: table => new
                {
                    menuId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    menuName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    menuDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    menuPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MenuTbl", x => x.menuId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MenuTbl");
        }
    }
}
