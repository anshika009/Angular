﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;


namespace HotelWebAPI.Models
{
    [Table("MenuTbl")]
    public class HotelClass
    {
        [Key]
        public int menuId { get; set; }
        public string menuName { get; set; } = string.Empty;
        public string menuDescription { get; set; } = string.Empty;
        public int menuPrice { get; set; }

    }

    public class BillContext : DbContext
    {
        public DbSet<HotelClass> BillData { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            const string conString = "Data Source=W-674PY03-1;Initial Catalog=AnshikaDB;Persist Security Info=True;User ID=sa;Password=Password@12345;TrustServerCertificate:True";
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer(conString);
        }
    }
    public interface IHotelComponent
    {
        List<HotelClass> GetAllMenu();
        HotelClass GetMenu(int id);
        void Addmenu(HotelClass emp);
        void UpdateMenu(HotelClass emp);
        void DeleteMenu(int id);
    }


    public class HotelComponent : IHotelComponent
    {
        
        

        public void Addmenu(HotelClass menu)
        {
            var context = new BillContext();
            context.BillData.Add(menu);
            context.SaveChanges();
        }

        public void DeleteMenu(int id)
        {
            var context = new BillContext();
            var rec = context.BillData.FirstOrDefault(e => e.menuId == id);
            if (rec != null)
            {
                context.BillData.Remove(rec);
                context.SaveChanges();
            }
            else
            {
                throw new Exception("Dish not found to delete");
            }
        }

        public List<HotelClass> GetAllMenu()
        {
            var context = new BillContext();
            return context.BillData.ToList();
        }

       

     

        public HotelClass GetMenu(int id)
        {
            var context = new BillContext();
            var rec = context.BillData.FirstOrDefault(e => e.menuId == id);
            if (rec != null)
            {
                return rec;
            }
            else
            {
                throw new Exception("Dish not found to delete...");
            }
        }

       

        public void UpdateMenu(HotelClass menu)
        {
            var context = new BillContext();
            var rec = context.BillData.FirstOrDefault(m => m.menuId == menu.menuId);
            if (rec != null)
            {
                rec.menuName = menu.menuName;
                rec.menuDescription = menu.menuDescription;
                rec.menuPrice = menu.menuPrice;
              
                context.SaveChanges();
            }
            else
            {
                throw new Exception("Dish not found to update!");
            }
        }
    }
}