import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppRoutingRoutingModule } from './app.routing-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AppRoutingRoutingModule
  ]
})
export class AppRoutingModule { }
