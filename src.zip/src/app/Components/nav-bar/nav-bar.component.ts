import { Component } from '@angular/core';
import { MenuService } from 'src/app/menu.service';
import { Menu } from 'src/app/Models/menu';
@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent {
  title : string = "Routing App on Menu!"
}
