import { Component, OnInit } from '@angular/core';
import { MenuService } from 'src/app/menu.service';

@Component({
  selector: 'app-menu-cart',
  templateUrl: './menu-cart.component.html',
  styleUrls: ['./menu-cart.component.css']
})
export class MenuCartComponent implements OnInit {
  menuList : Menu[] = [];
  constructor(private service : MenuService){

  }
  ngOnInit(): void {
      this.service.getAllMenu().subscribe((data:Menu[])=>{
          this.menuList = data
      });
  }

}
