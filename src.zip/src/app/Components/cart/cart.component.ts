import { Component } from '@angular/core';
import { Menu } from 'src/app/Models/menu';
import { MenuService } from 'src/app/menu.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {

}
