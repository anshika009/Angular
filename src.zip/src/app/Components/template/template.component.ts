import { Component, OnInit } from '@angular/core';
import { Menu } from 'src/app/Models/menu';
@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.css']
})
export class TemplateComponent implements OnInit {
  men : Menu = {} as Menu;

  ngOnInit(): void {
      this.men = {
        menuDescription:"",
        menuImage :"",
        menuName:"",
        id:0,
        menuPrice:
      }
   }
   onSubmit(menuForm: any) {
    console.log(menuForm.value);
  }

}
