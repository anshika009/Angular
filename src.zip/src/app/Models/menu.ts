export interface Menu {
    id:number,
    menuName:string,
    menuDescription:string,
    menuPrice:number,
    menuImage:string
}
